# Tkinter UI view


from __future__ import annotations

import datetime as dt
import tkinter as tk
from collections.abc import Callable
from tkinter import ttk
from typing import Any


# the main app view
class MainView:
    # columns for items table
    COLUMNS = (
        "id",
        "name",
        "category",
        "date_found",
        "date_lost",
        "location",
        "status",
        "contact_info",
    )

    STATUS_VALUES = ("found", "lost", "claimed")

    # build up the UI on init
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        # event handlers for the buttons
        self._on_refresh: Callable[[], None] = lambda: None
        self._on_add: Callable[[], None] = lambda: None
        self._on_edit: Callable[[], None] = lambda: None
        self._on_save: Callable[[], None] = lambda: None
        self._on_delete: Callable[[], None] = lambda: None
        self._on_clear: Callable[[], None] = lambda: None
        self._on_apply_filters: Callable[[], None] = lambda: None
        self._on_clear_filters: Callable[[], None] = lambda: None
        # the ID of the item being edited
        self._editing_id: int | None = None

        root.title("Lost & Found")
        root.minsize(880, 520)

        main = ttk.Frame(root, padding=8)
        main.pack(fill=tk.BOTH, expand=True)

        form = ttk.LabelFrame(main, text="Item details", padding=8)
        form.pack(fill=tk.X, pady=(0, 8))

        # variables for the form
        self.var_name = tk.StringVar()
        self.var_category = tk.StringVar()
        self.var_date_found = tk.StringVar()
        self.var_date_lost = tk.StringVar()
        self.var_location = tk.StringVar()
        self.var_status = tk.StringVar(value="found")
        self.var_contact = tk.StringVar()

        # variables for the filters
        self.var_filter_category = tk.StringVar(value="All")
        self.var_filter_status = tk.StringVar(value="All")
        self.var_filter_search = tk.StringVar()

        # buttons
        crud = ttk.Frame(main)
        crud.pack(fill=tk.X, pady=(0, 8))
        ttk.Button(crud, text="Add new", command=self._click_add).pack(
            side=tk.LEFT, padx=(0, 4)
        )
        ttk.Button(crud, text="Edit selected", command=self._click_edit).pack(
            side=tk.LEFT, padx=(0, 4)
        )
        ttk.Button(
            crud,
            text="Delete selected",
            command=self._click_delete,
        ).pack(side=tk.LEFT, padx=(0, 4))

        ttk.Button(
            crud,
            text="Refresh list",
            command=self._click_refresh,
        ).pack(side=tk.LEFT, padx=(16, 0))

        # frame for the filters
        filters = ttk.LabelFrame(main, text="Filters", padding=8)
        filters.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(filters, text="Category:").grid(
            row=0, column=0, sticky=tk.W, padx=(0, 6), pady=2
        )
        self.category_filter_combo = ttk.Combobox(
            filters,
            textvariable=self.var_filter_category,
            values=("All",),
            state="readonly",
            width=18,
        )
        self.category_filter_combo.grid(
            row=0, column=1, sticky=tk.W, padx=(0, 10), pady=2
        )
        ttk.Label(filters, text="Status:").grid(
            row=0, column=2, sticky=tk.W, padx=(0, 6), pady=2
        )
        status_options = ("All",) + self.STATUS_VALUES
        ttk.Combobox(
            filters,
            textvariable=self.var_filter_status,
            values=status_options,
            state="readonly",
            width=14,
        ).grid(row=0, column=3, sticky=tk.W, padx=(0, 10), pady=2)
        ttk.Label(filters, text="Search (name/category):").grid(
            row=0, column=4, sticky=tk.W, padx=(0, 6), pady=2
        )
        ttk.Entry(
            filters, textvariable=self.var_filter_search, width=24
        ).grid(row=0, column=5, sticky=tk.W, padx=(0, 10), pady=2)
        ttk.Button(
            filters, text="Apply", command=self._click_apply_filters
        ).grid(row=0, column=6, sticky=tk.W, padx=(0, 4), pady=2)
        ttk.Button(
            filters, text="Clear", command=self._click_clear_filters
        ).grid(row=0, column=7, sticky=tk.W, pady=2)

        # frame for the items table
        ttk.Label(main, text="All items").pack(anchor=tk.W)
        tree_frame = ttk.Frame(main)
        tree_frame.pack(fill=tk.BOTH, expand=True)

        # the items table
        self.tree = ttk.Treeview(
            tree_frame,
            columns=self.COLUMNS,
            show="headings",
            height=10,
        )
        for col in self.COLUMNS:  # set the headings and columns
            self.tree.heading(col, text=col.replace("_", " ").title())
            self.tree.column(col, width=95, minwidth=50)
        self.tree.column("id", width=36, minwidth=36)  # set ID column width

        # the scrollbar
        scroll = ttk.Scrollbar(
            tree_frame, orient=tk.VERTICAL, command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        self.tree.bind("<Double-1>", self._on_tree_double_click)

    # called when the relecvent button is clicked
    def _click_add(self) -> None:
        self._on_add()

    def _click_edit(self) -> None:
        self._on_edit()

    def _click_save(self) -> None:
        self._on_save()

    def _click_delete(self) -> None:
        self._on_delete()

    def _click_clear(self) -> None:
        self._on_clear()

    # called when an item is selected in the table - set the current selection
    def _on_tree_select(self, _event: tk.Event[Any]) -> None:
        # get the selected item
        sel = self.tree.selection()
        if not sel:
            return
        values = self.tree.item(sel[0], "values")
        if values and len(values) >= 8:
            self._load_row(values)

    def _on_tree_double_click(self, _event: tk.Event[Any]) -> None:
        if self.get_selected_item_id() is not None:
            self._on_edit()

    # load the selected item into the form
    def _load_row(self, values: tuple[Any, ...]) -> None:
        self._editing_id = int(values[0])
        self.var_name.set(str(values[1]))
        self.var_category.set(str(values[2]))
        self.var_date_found.set(str(values[3] or ""))
        self.var_date_lost.set(str(values[4] or ""))
        self.var_location.set(str(values[5]))
        self.var_status.set(str(values[6]).lower())
        self.var_contact.set(str(values[7]))

    def set_refresh_handler(self, handler: Callable[[], None]) -> None:
        self._on_refresh = handler

    def set_add_handler(self, handler: Callable[[], None]) -> None:
        self._on_add = handler

    def set_edit_handler(self, handler: Callable[[], None]) -> None:
        self._on_edit = handler

    def set_save_handler(self, handler: Callable[[], None]) -> None:
        self._on_save = handler

    def set_delete_handler(self, handler: Callable[[], None]) -> None:
        self._on_delete = handler

    def set_clear_handler(self, handler: Callable[[], None]) -> None:
        self._on_clear = handler

    def set_apply_filters_handler(self, handler: Callable[[], None]) -> None:
        self._on_apply_filters = handler

    def set_clear_filters_handler(self, handler: Callable[[], None]) -> None:
        self._on_clear_filters = handler

    def _click_refresh(self) -> None:
        self._on_refresh()

    def _click_apply_filters(self) -> None:
        self._on_apply_filters()

    def _click_clear_filters(self) -> None:
        self._on_clear_filters()

    def get_filter_values(self) -> tuple[str, str, str]:
        category = self.var_filter_category.get().strip()
        status = self.var_filter_status.get().strip()
        return (
            "" if category.lower() == "all" else category,
            "" if status.lower() == "all" else status,
            self.var_filter_search.get().strip(),
        )

    def clear_filters(self) -> None:
        self.var_filter_category.set("All")
        self.var_filter_status.set("All")
        self.var_filter_search.set("")

    def set_filter_categories(self, categories: list[str]) -> None:
        """Update category filter options from DB values."""
        current = self.var_filter_category.get().strip() or "All"
        values = ("All",) + tuple(categories)
        self.category_filter_combo["values"] = values
        if current not in values:
            self.var_filter_category.set("All")

    def get_form_payload(self) -> dict[str, str]:
        """Dict keys match backend.model (API field names)."""
        return {
            "name": self.var_name.get().strip(),
            "category": self.var_category.get().strip(),
            "date_found": self.var_date_found.get().strip(),
            "date_lost": self.var_date_lost.get().strip(),
            "location": self.var_location.get().strip(),
            "status": self.var_status.get().strip(),
            "contact_info": self.var_contact.get().strip(),
        }

    def show_create_dialog(self) -> dict[str, str] | None:
        """Open a pop-up form for creating a new item."""
        return self._show_item_dialog(
            title="Add item",
            submit_text="Create",
            item_id=None,
            initial={"status": "lost"},
            hidden_fields={"date_found", "status"},
        )

    def show_edit_dialog(
        self,
        item_id: int,
        initial: dict[str, str],
    ) -> dict[str, str] | None:
        """Open edit dialog for an existing item (ID read-only)."""
        return self._show_item_dialog(
            title=f"Edit item #{item_id}",
            submit_text="Save changes",
            item_id=item_id,
            initial=initial,
        )

    def _show_item_dialog(
        self,
        title: str,
        submit_text: str,
        item_id: int | None,
        initial: dict[str, str] | None,
        hidden_fields: set[str] | None = None,
    ) -> dict[str, str] | None:
        """Common create/edit dialog UI used by Add and Edit flows."""
        top = tk.Toplevel(self.root)
        top.title(title)
        top.transient(self.root)
        top.grab_set()
        top.resizable(False, False)

        vars_map = {
            "name": tk.StringVar(value=(initial or {}).get("name", "")),
            "category": tk.StringVar(
                value=(initial or {}).get("category", "")
            ),
            "date_found": tk.StringVar(
                value=(initial or {}).get("date_found", "")
            ),
            "date_lost": tk.StringVar(
                value=(initial or {}).get("date_lost", "")
            ),
            "location": tk.StringVar(
                value=(initial or {}).get("location", "")
            ),
            "status": tk.StringVar(
                value=(initial or {}).get("status", "found").lower()
            ),
            "contact_info": tk.StringVar(
                value=(initial or {}).get("contact_info", "")
            ),
        }

        frame = ttk.Frame(top, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        start_row = 0
        if item_id is not None:
            ttk.Label(frame, text="ID:").grid(
                row=0, column=0, sticky=tk.W, padx=(0, 8), pady=3
            )
            ttk.Label(frame, text=str(item_id)).grid(
                row=0, column=1, sticky=tk.W, pady=3
            )
            start_row = 1

        hidden = hidden_fields or set()
        labels = [
            ("Name", "name"),
            ("Category", "category"),
            ("Date Found (YYYY-MM-DD)", "date_found"),
            ("Date Lost (YYYY-MM-DD)", "date_lost"),
            ("Location", "location"),
            ("Status", "status"),
            ("Contact", "contact_info"),
        ]
        visible_labels = [pair for pair in labels if pair[1] not in hidden]
        for row, (label, key) in enumerate(visible_labels):
            row_idx = row + start_row
            ttk.Label(frame, text=f"{label}:").grid(
                row=row_idx, column=0, sticky=tk.W, padx=(0, 8), pady=3
            )
            if key == "status":
                combo = ttk.Combobox(
                    frame,
                    textvariable=vars_map[key],
                    values=self.STATUS_VALUES,
                    state="readonly",
                    width=28,
                )
                combo.grid(row=row_idx, column=1, sticky=tk.W, pady=3)
            elif key in {"date_found", "date_lost"}:
                date_row = ttk.Frame(frame)
                date_row.grid(row=row_idx, column=1, sticky=tk.EW, pady=3)
                ttk.Entry(
                    date_row,
                    textvariable=vars_map[key],
                    width=24,
                ).pack(side=tk.LEFT, fill=tk.X, expand=True)
                ttk.Button(
                    date_row,
                    text="Pick...",
                    command=lambda v=vars_map[key]:
                    self._set_date_from_picker(v),
                ).pack(side=tk.LEFT, padx=(4, 0))
            else:
                ttk.Entry(
                    frame,
                    textvariable=vars_map[key],
                    width=32,
                ).grid(row=row_idx, column=1, sticky=tk.EW, pady=3)
        frame.columnconfigure(1, weight=1)

        result: dict[str, str] | None = None

        def on_create() -> None:
            nonlocal result
            result = {
                "name": vars_map["name"].get().strip(),
                "category": vars_map["category"].get().strip(),
                "date_found": vars_map["date_found"].get().strip(),
                "date_lost": vars_map["date_lost"].get().strip(),
                "location": vars_map["location"].get().strip(),
                "status": vars_map["status"].get().strip(),
                "contact_info": vars_map["contact_info"].get().strip(),
            }
            top.destroy()

        btns = ttk.Frame(frame)
        btns.grid(
            row=len(visible_labels) + start_row,
            column=0,
            columnspan=2,
            sticky=tk.E,
            pady=(8, 0),
        )
        ttk.Button(btns, text="Cancel", command=top.destroy).pack(
            side=tk.RIGHT, padx=(4, 0)
        )
        ttk.Button(
            btns,
            text=submit_text,
            command=on_create,
        ).pack(side=tk.RIGHT)

        top.wait_window()
        return result

    def _set_date_from_picker(self, target_var: tk.StringVar) -> None:
        picked = self._open_date_picker(target_var.get().strip())
        if picked is not None:
            target_var.set(picked)

    # open the date picker dialog - returns the date as YYYY-MM-DD or None
    def _open_date_picker(self, initial_date: str) -> str | None:
        top = tk.Toplevel(self.root)
        top.title("Select date")
        top.transient(self.root)
        top.grab_set()
        top.resizable(False, False)

        today = dt.date.today()
        default = today
        if initial_date:
            try:
                default = dt.date.fromisoformat(initial_date)
            except ValueError:
                default = today

        y_var = tk.IntVar(value=default.year)
        m_var = tk.IntVar(value=default.month)
        d_var = tk.IntVar(value=default.day)
        result: str | None = None

        frame = ttk.Frame(top, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(frame, text="Year").grid(
            row=0, column=0, sticky=tk.W, padx=(0, 6)
        )
        ttk.Label(frame, text="Month").grid(
            row=0, column=1, sticky=tk.W, padx=(0, 6)
        )
        ttk.Label(frame, text="Day").grid(row=0, column=2, sticky=tk.W)

        y_spin = ttk.Spinbox(
            frame,
            from_=2000,
            to=2100,
            textvariable=y_var,
            width=8,
        )
        m_spin = ttk.Spinbox(
            frame,
            from_=1,
            to=12,
            textvariable=m_var,
            width=6,
        )
        d_spin = ttk.Spinbox(
            frame,
            from_=1,
            to=31,
            textvariable=d_var,
            width=6,
        )
        y_spin.grid(row=1, column=0, sticky=tk.W, padx=(0, 6))
        m_spin.grid(row=1, column=1, sticky=tk.W, padx=(0, 6))
        d_spin.grid(row=1, column=2, sticky=tk.W)

        msg = tk.StringVar(value="")
        ttk.Label(frame, textvariable=msg, foreground="red").grid(
            row=2, column=0, columnspan=3, sticky=tk.W, pady=(6, 0)
        )

        # on OK, set the result to the date and close the dialog
        def on_ok() -> None:
            nonlocal result
            try:
                picked = dt.date(y_var.get(), m_var.get(), d_var.get())
            except ValueError:
                msg.set("Invalid date")
                return
            result = picked.isoformat()
            top.destroy()

        btns = ttk.Frame(frame)
        btns.grid(
            row=3,
            column=0,
            columnspan=3,
            sticky=tk.E,
            pady=(8, 0),
        )

        # on Cancel, close the dialog
        ttk.Button(btns, text="Cancel", command=top.destroy).pack(
            side=tk.RIGHT, padx=(4, 0)
        )
        ttk.Button(btns, text="OK", command=on_ok).pack(side=tk.RIGHT)

        top.wait_window()
        return result

    # get the ID of the item being edited
    def get_editing_id(self) -> int | None:
        return self._editing_id

    # clear the form - reset the form variables and the selected item
    def clear_form(self) -> None:
        self._editing_id = None
        self.var_name.set("")
        self.var_category.set("")
        self.var_date_found.set("")
        self.var_date_lost.set("")
        self.var_location.set("")
        self.var_status.set("found")
        self.var_contact.set("")
        for iid in self.tree.selection():
            self.tree.selection_remove(iid)

    # get the ID of the item to delete
    def delete_target_id(self) -> int | None:
        sel = self.tree.selection()
        if not sel:
            return None
        vals = self.tree.item(sel[0], "values")
        if not vals:
            return None
        return int(vals[0])

    # get the ID of the selected item
    def get_selected_item_id(self) -> int | None:
        sel = self.tree.selection()
        if not sel:
            return None
        vals = self.tree.item(sel[0], "values")
        if not vals:
            return None
        return int(vals[0])

    # set the rows in the table
    def set_rows(self, rows: list[tuple[Any, ...]]) -> None:
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        for row in rows:
            self.tree.insert("", tk.END, values=row)
